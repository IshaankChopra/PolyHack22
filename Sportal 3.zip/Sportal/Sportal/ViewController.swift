//
//  ViewController.swift
//  Sportal
//
//  Created by Apple on 02/06/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var txtUserName: UITextField!{
        didSet {
            txtUserName.layer.cornerRadius = 25
//            txtUserName.layer.borderWidth = 1
//            txtUserName.layer.borderColor = UIColor.black.cgColor
            txtUserName.layer.masksToBounds = true
        }
    }
    @IBOutlet var txtPassword: UITextField!{
        didSet {
            txtPassword.layer.cornerRadius = 25
//            txtPassword.layer.borderWidth = 1
//            txtPassword.layer.borderColor = UIColor.black.cgColor
            txtPassword.layer.masksToBounds = true
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnForgotPss(_ sender: Any) {
    
    }
    
    @IBAction func btnLogin(_ sender: Any) {
        if !txtUserName.hasText{
           Utility.showAlert(title: "Alert!!", message: "Please enter a username.", viewController: self)
       } else if !txtPassword.hasText {//- USA format as (544) 555-5555-10 digit
            Utility.showAlert(title: "Alert!!", message: "Please enter password.", viewController: self)
       } else {
        let objLogin = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ContinueViewController")as! ContinueViewController
        self.navigationController?.pushViewController(objLogin, animated: true)
       }
    }
    
    @IBAction func adminBtnLogin(_ sender: Any) {
        let objLogin = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AdminViewController")as! AdminViewController
        self.navigationController?.pushViewController(objLogin, animated: true)
    }
    
    @IBAction func btnSignup(_ sender: Any) {
    
    }

}

