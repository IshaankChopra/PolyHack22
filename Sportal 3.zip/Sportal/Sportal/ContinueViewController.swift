//
//  ContinueViewController.swift
//  Sportal
//
//  Created by Apple on 02/06/22.
//

import UIKit

class ContinueViewController: UIViewController {
    var arrName = ["Football","Basketball","Badminton","Rugby","Tennis ","Baseball","Table Tennis","Volleyball","Cricket","Others..."]
    
    var isSelect = -1
    @IBOutlet weak var collViewList: UICollectionView!
    
    var arrSelectedRow : [Int] = []
    
    //MARK: View Life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.collViewList.reloadData()
        // Do any additional setup after loading the view.
    }
    

    @IBAction func continueAction(_ sender: Any) {
        let objLogin = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeViewController")as! HomeViewController
        self.navigationController?.pushViewController(objLogin, animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension ContinueViewController : UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    // Layout: Set Edges
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0) // top, left, bottom, right
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let size = CGSize(width: 177, height: 60)
        return size
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 4;
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 1;
    }
    
    //UICollectionViewDatasource methods
    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier:"ContinueViewCell", for: indexPath) as! ContinueViewCell
        cell.lblName.text = arrName[indexPath.row]
        
        if arrSelectedRow.contains(indexPath.row) {
            cell.imgView.image = UIImage(named: "SelectedBox")
        } else {
            cell.imgView.image = UIImage(named: "UnSelectedBox")
        }
//        if isSelect == indexPath.row{
//            cell.imgView.image = UIImage(named: "SelectedBox")
//        }else{
//            cell.imgView.image = UIImage(named: "UnSelectedBox")
//        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        arrSelectedRow.append(indexPath.row)
        isSelect = indexPath.row
        collViewList.reloadData()
    }
}

    
    
   
