//
//  ContinueViewCell.swift
//  Sportal
//
//  Created by gauri shankar prasad on 02/06/22.
//

import UIKit

class ContinueViewCell: UICollectionViewCell {
    @IBOutlet var imgView: UIImageView!
    @IBOutlet var lblName: UILabel!
}
