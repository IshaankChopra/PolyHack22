//
//  HomeViewCell.swift
//  Sportal
//
//  Created by gauri shankar prasad on 02/06/22.
//

import UIKit

class HomeViewCell: UITableViewCell {
    

    @IBOutlet weak var viewBg: UIView!{
        didSet {
            viewBg.layer.cornerRadius = 10
            
        }
    }
    @IBOutlet weak var lblTitle: UILabel!
        @IBOutlet weak var imgStar: UIImageView!
        @IBOutlet weak var imgThumb: UIImageView!{
            didSet {
                imgThumb.layer.cornerRadius = 10
                
            }
        }
        @IBOutlet weak var lblAddress: UILabel!
        @IBOutlet weak var lblDayOpen: UILabel!
        @IBOutlet weak var lblTime: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
