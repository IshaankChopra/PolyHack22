//
//  HomeViewController.swift
//  Sportal
//
//  Created by Apple on 02/06/22.
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var lblCurrentAway: UILabel!
    var arrName = [["Title":"Shek Kip Mei Basketball Court(10$)","ThumbImg":"02.png","StarImg":"StarFive.png","Address":"Address: 270 Nam Cheong Street, Sham Shul Po","Days":"Days open: Everyday","Time":"Time open: 8AM - 9PM"],["Title":"Chai Wan Centre Badminton Court(8$)","ThumbImg":"05.png","StarImg":"StarThree.png","Address":"Address: Yee Shun Street, Chai Wan","Days":"Days open: Mon-Sat","Time":"Time open: 8AM - 8PM"],["Title":"Ngau Chi Wan Park Archery Range(15$)","ThumbImg":"02.png","StarImg":"StarFive.png","Address":"Address: 71 Fung Shing Street, Ngau Chi Wong Tai Sin, Kowloon","Days":"Days open: Everyday","Time":"Time open: 10AM - 6:30PM"]]

    @IBOutlet weak var tblList: UITableView!
    var selectedRowDisplay = 3
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        lblCurrentAway.text = "Currently Available"
    }
    
    @IBAction func myBookingAction(_ sender: Any) {
        let objLogin = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "BookingVC")as! BookingVC
        self.navigationController?.pushViewController(objLogin, animated: true)
    }
    
    @IBAction func locationAction(_ sender: Any) {
        lblCurrentAway.text = "3KM away"
        selectedRowDisplay = 1
        tblList.reloadData()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension HomeViewController: UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return selectedRowDisplay
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

            let cell:HomeViewCell = tableView.dequeueReusableCell(withIdentifier: "HomeViewCell") as! HomeViewCell
        let dictData = arrName[indexPath.row]
        cell.lblTitle.text = dictData["Title"]
        cell.lblAddress.text = dictData["Address"]
        cell.lblDayOpen.text = dictData["Days"]
        cell.lblTime.text = dictData["Time"]
        cell.imgStar.image = UIImage(named: dictData["StarImg"] ?? "")
        cell.imgThumb.image = UIImage(named: dictData["ThumbImg"] ?? "")
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let objPost = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeDetailsViewController") as! HomeDetailsViewController
        self.navigationController?.pushViewController(objPost, animated: true)
    }
    
}

