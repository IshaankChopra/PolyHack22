//
//  BookingVC.swift
//  Sportal
//
//  Created by gauri shankar prasad on 03/06/22.
//

import UIKit

class BookingVC: UIViewController {

    @IBOutlet weak var viewBG: UIView!{
        didSet {
            viewBG.layer.cornerRadius = 30
            viewBG.layer.masksToBounds = true
        }
    }
    @IBOutlet weak var viewBooking: UIView!
    @IBOutlet weak var viewVerified: UIView!
    @IBOutlet weak var viewBeacon: UIView!{
        didSet {
            viewBeacon.layer.cornerRadius = 30
            viewBeacon.layer.masksToBounds = true
        }
    }
    
    var timer = Timer()
    
    //MARK: View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        viewBeacon.isHidden = true
        viewBooking.isHidden = false
        viewVerified.isHidden = true
        
    }
    
    //new function
    @objc func timerAction(){
        print("timer fired!")
        self.viewVerified.isHidden = false
        self.viewBooking.isHidden = true
        self.viewBeacon.isHidden = true
    }
    
    @IBAction func facilityAccessAction(_ sender: Any) {
        self.viewBeacon.isHidden = false

        timer = Timer.scheduledTimer(timeInterval: 4.0, target: self, selector: #selector(timerAction), userInfo: nil, repeats: true)
    }

    @IBAction func homeTabAction(_ sender: Any) {
        let objPost = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
        self.navigationController?.pushViewController(objPost, animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
